﻿
using System.Diagnostics;

namespace Lygiagretinimas
{
	class Program
	{
		public static long FIRST(int[] arr)
		{
			long n = arr.Length;
			long k = n;

			Parallel.For(0, arr.Length, i =>
			{
				if (arr[i] / 7 == 0)
				{
					k -= 2;
				}
				else
				{
					k += 3;
				}
			});
			if (arr[0] > 0)
			{
				Parallel.For(0, n * n, i =>
				{
					if (arr[0] > 0)
					{
						k += 3;
					}
				});
			}
			return k;
		}
		//public static long methodToAnalysis(int[] arr)
		//{
		//	long n = arr.Length;
		//	long k = n;
		//	for (int i = 0; i < n; i++)
		//	{
		//		if (arr[i] / 7 == 0)
		//		{
		//			k -= 2;
		//		}
		//		else
		//		{
		//			k += 3;
		//		}
		//	}
		//	if (arr[0] > 0)
		//	{
		//		for (int i = 0; i < n * n; i++)
		//		{
		//			if (arr[0] > 0)
		//			{
		//				k += 3;
		//			}
		//		}
		//	}
		//	return k;
		//}


		static object monitor = new object();
		static int threadCount = 0;
		public static long SecondMethodToAnalysisParallel2(int n, int[] arr)
		{
			long[] localKArray = new long[n - 1];
			object lockObj = new object();

			Parallel.For(1, n, i =>
			{
				long localK = 0;
				localK += FF10Parallel(i, arr);
				localK += FF10Parallel(i / i, arr);
				localKArray[i - 1] = localK;
			});

			long k = 0;
			lock (lockObj)
			{
				for (int i = 0; i < localKArray.Length; i++)
				{
					k += k;
					k += localKArray[i];
				}
			}

			return k;
		}

		public static long FF10Parallel(int n, int[] arr)
		{
			long first = 0;
			long second = 0;

			if (n > 1 && arr.Length > n)
			{
				Task task1 = Task.Run(() => first = FF10Parallel(n - 2, arr));
				Task task2 = Task.Run(() => second = FF10Parallel(n / n, arr));
				Task.WaitAll(task1, task2);
				return first + second;
			}
			return n;
		}
		public static long FF10(int n, int[] arr)
		{

			if (n > 1 && arr.Length > n)
			{
				return FF10(n - 2, arr) + FF10(n / n, arr);
			}
			return n;
		}

		public static long SecondMethodToAnalysisParallel(int n, int[] arr)
		{
			long[] localKArray = new long[n - 1];
			object lockObj = new object();

			Parallel.For(1, n, i =>
			{
				long localK = 0;
				localK += FF10(i, arr);
				localK += FF10(i / i, arr);
				localKArray[i - 1] = localK;
			});

			long k = 0;
			lock (lockObj)
			{
				for (int i = 0; i < localKArray.Length; i++)
				{
					k += k;
					k += localKArray[i];
				}
			}

			return k;
		}

		//public static long methodToAnalysis(int n, int[] arr)
		//{
		//	long k = 0;
		//	for (int i = 1; i < n; i++)
		//	{
		//		k += k;
		//		k += FF10(i, arr);
		//		k += FF10(i / i, arr);
		//	}

		//	return k;
		//}

		//public static long FF10(int n, int[] arr)
		//{
		//	if (n > 1 && arr.Length > n)
		//	{
		//		return FF10(n - 2, arr) + FF10(n / n, arr);
		//	}
		//	return n;
		//}

		public static int[] GenerateRandomArray(int length, int minValue, int maxValue)
		{
			Random random = new Random();
			int[] arr = new int[length];
			for (int i = 0; i < length; i++)
			{
				arr[i] = random.Next(minValue, maxValue);
			}
			return arr;
		}


		static void Main(string[] args)
		{
			var stopWatch = new Stopwatch();
			int[] values = GenerateRandomArray(7500, 1, 7500);
			int n = 7500;
			//stopWatch.Start();
			//Console.WriteLine("First result: " + methodToAnalysis(values));
			//stopWatch.Stop();
			//Console.WriteLine("Time in milliseconds for FIRST({1}): {0} ms", stopWatch.ElapsedMilliseconds.ToString(), n);

			stopWatch.Reset();
			stopWatch.Start();
			Console.WriteLine("Second result: " + SecondMethodToAnalysisParallel(n, values));
			stopWatch.Stop();
			Console.WriteLine("Time in milliseconds for SECOND({1}): {0} ms", stopWatch.ElapsedMilliseconds.ToString(), n);
		}
	}
}