﻿using System;

public class TreeNode
{
	public int Value { get; set; }
	public TreeNode Left { get; set; }
	public TreeNode Right { get; set; }
}

public class TaskUtils
{
	public static int MaxSum(TreeNode root)
	{
		int maxDepth = GetDepth(root);
		int[,] maxSums = new int[maxDepth + 1, 2];

		// Initialize leaf node values
		for (int i = 0; i < maxDepth; i++)
		{
			TreeNode node = GetNode(root, i);
			maxSums[i, 1] = node.Value;
		}

		// Calculate max sums for non-leaf nodes
		for (int i = maxDepth - 1; i >= 0; i--)
		{
			TreeNode node = GetNode(root, i);
			int childDepth = i + 1;
			int maxSumWithoutChild = maxSums[i + 1, 0];
			int maxSumWithChild = node.Value + maxSums[childDepth, 1];

			maxSums[i, 0] = Math.Max(maxSumWithoutChild, maxSumWithChild);
			maxSums[i, 1] = maxSumWithoutChild;
		}

		return maxSums[0, 0];
	}

	// Helper function to get the depth of a tree
	public static int GetDepth(TreeNode node)
	{
		if (node == null)
		{
			return 0;
		}

		int leftDepth = GetDepth(node.Left);
		int rightDepth = GetDepth(node.Right);

		return Math.Max(leftDepth, rightDepth) + 1;
	}

	// Helper function to get the node at a given depth
	public static TreeNode GetNode(TreeNode node, int depth)
	{
		if (depth == 0)
		{
			return node;
		}

		int childDepth = depth - 1;
		if (GetDepth(node.Left) > childDepth)
		{
			return GetNode(node.Left, childDepth);
		}
		else
		{
			return GetNode(node.Right, childDepth - GetDepth(node.Left));
		}
	}
}
public class Program
{
	public static void Main()
	{
		TreeNode node1 = new TreeNode { Value = 1 };
		TreeNode node2 = new TreeNode { Value = 2 };
		TreeNode node3 = new TreeNode { Value = 3 };
		TreeNode node5 = new TreeNode { Value = 5 };
		TreeNode node7 = new TreeNode { Value = 7 };
		TreeNode node9 = new TreeNode { Value = 9 };

		node2.Left = node1;
		node2.Right = node3;
		node7.Right = node9;
		node5.Left = node2;
		node5.Right = node7;
		int maxSum = TaskUtils.MaxSum(node5);
		Console.WriteLine(maxSum); // Output: 18



	}
}
