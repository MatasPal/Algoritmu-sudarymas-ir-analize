﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.Drawing;

namespace PirmaUzduotis
{
	public class Node
	{
		public int Value { get; set; }
		public List<Node> Children { get; set; }

		public Node(int value)
		{
			Value = value;
			Children = new List<Node>();
		}

	}

	class TaskUtils
	{
		public static int FindMaxSumRecursion(Node node)
		{
			int included = node.Value;
			foreach (var child in node.Children)
			{
				foreach (var grandchild in child.Children)
				{
					included += FindMaxSumRecursion(grandchild);
				}
			}
			int excluded = 0;
			foreach (var child in node.Children)
			{
				excluded += FindMaxSumRecursion(child);
			}
			return Math.Max(included, excluded);
		}

		public static int FindMaxSumDynamic(Node node)
		{
			Dictionary<Node, int> memo = new Dictionary<Node, int>();
			return FindMaxSumHelper(node, memo);
		}

		public static int FindMaxSumHelper(Node node, Dictionary<Node, int> memo)
		{
			if (memo.ContainsKey(node))
			{
				return memo[node];
			}
			int included = node.Value;
			foreach (var child in node.Children)
			{
				foreach (var grandchild in child.Children)
				{
					included += FindMaxSumHelper(grandchild, memo);
				}
			}
			int excluded = 0;
			foreach (var child in node.Children)
			{
				excluded += FindMaxSumHelper(child, memo);
			}
			int result = Math.Max(included, excluded);
			memo[node] = result;
			return result;
		}
	}



	class Program
	{
		static void Main(string[] args)
		{
			//Create a sample tree
			Node root = new Node(10);
			Node node1 = new Node(20);
			Node node2 = new Node(30);
			Node node3 = new Node(40);
			Node node4 = new Node(50);
			Node node5 = new Node(60);
			Node node6 = new Node(70);
			Node node7 = new Node(80);

			root.Children.Add(node1);
			root.Children.Add(node2);
			node1.Children.Add(node3);
			node1.Children.Add(node4);
			node2.Children.Add(node5);
			node2.Children.Add(node6);
			node5.Children.Add(node7);

			// Find the maximum sum using recursion
			int maxSumRecursion = TaskUtils.FindMaxSumRecursion(root);
			Console.WriteLine("Maximum sum using recursion: " + maxSumRecursion);


			int maxSumDynamicProgramming = TaskUtils.FindMaxSumDynamic(root);
			Console.WriteLine("Maximum sum using dynamic programming: " + maxSumDynamicProgramming);

			//The answer of 250 is obtained by selecting the following nodes from the tree:
			//	Node with value 40
			//	Node with value 50
			//	Node with value 70
			//	Node with value 80

			//These nodes have a total value of 40 + 50 + 70 + 80 = 250, and satisfy the constraint that no node is included whose parent is already included. 
			//Note that we cannot select node 60, since its parent node 30 is already included.
			//To find the maximum sum of values that can be assigned to nodes in the tree, the MaxSum method uses a dynamic programming approach.
			//It calculates the maximum sum of values that can be obtained by including and excluding each node in the tree, and uses memoization to avoid redundant computations.

		}

	}
}