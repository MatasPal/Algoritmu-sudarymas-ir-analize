﻿using System;

public class Node
{
	public int Value { get; set; }
	public Node Left { get; set; }
	public Node Right { get; set; }

	public Node(int value)
	{
		Value = value;
	}
}

public class TaskUtils
{
	//public static int MaxSumDynamic(Node root)
	//{
	//	if (root == null)
	//	{
	//		return 0;
	//	}

	//	int[] dp = new int[2];
	//	dp[0] = MaxSumDynamic(root.Left) + MaxSumDynamic(root.Right); // max sum excluding current node
	//	dp[1] = root.Value; // max sum including current node

	//	if (root.Left != null)
	//	{
	//		dp[1] += MaxSumDynamic(root.Left.Left) + MaxSumDynamic(root.Left.Right);
	//	}

	//	if (root.Right != null)
	//	{
	//		dp[1] += MaxSumDynamic(root.Right.Left) + MaxSumDynamic(root.Right.Right);
	//	}

	//	return Math.Max(dp[0], dp[1]);
	//}
	public static int MaxSumDynamic(Node root)
	{
		if (root == null)
		{
			return 0;
		}

		Stack<Node> stack = new Stack<Node>();
		Dictionary<Node, int> maxSumExcluding = new Dictionary<Node, int>();
		Dictionary<Node, int> maxSumIncluding = new Dictionary<Node, int>();

		stack.Push(root);
		maxSumExcluding[root] = 0;
		maxSumIncluding[root] = root.Value;

		while (stack.Count > 0)
		{
			Node node = stack.Peek();

			if (node.Left != null && !maxSumExcluding.ContainsKey(node.Left))
			{
				stack.Push(node.Left);
				maxSumExcluding[node.Left] = 0;
				maxSumIncluding[node.Left] = node.Left.Value;
			}
			else if (node.Right != null && !maxSumExcluding.ContainsKey(node.Right))
			{
				stack.Push(node.Right);
				maxSumExcluding[node.Right] = 0;
				maxSumIncluding[node.Right] = node.Right.Value;
			}
			else
			{
				stack.Pop();

				int sumExcluding = maxSumIncluding.GetValueOrDefault(node.Left, 0) + maxSumIncluding.GetValueOrDefault(node.Right, 0);
				maxSumExcluding[node] = sumExcluding;

				int sumIncluding = node.Value + maxSumExcluding.GetValueOrDefault(node.Left, 0) + maxSumExcluding.GetValueOrDefault(node.Right, 0);
				maxSumIncluding[node] = sumIncluding;
			}
		}

		return Math.Max(maxSumExcluding[root], maxSumIncluding[root]);
	}




	public static int MaxSumRecursion(Node root)
	{
		if (root == null)
		{
			return 0;
		}

		int sumWithRoot = root.Value;
		int sumWithoutRoot = 0;

		if (root.Left != null)
		{
			sumWithRoot += MaxSumRecursion(root.Left.Left) + MaxSumRecursion(root.Left.Right);
			sumWithoutRoot += MaxSumRecursion(root.Left);
		}

		if (root.Right != null)
		{
			sumWithRoot += MaxSumRecursion(root.Right.Left) + MaxSumRecursion(root.Right.Right);
			sumWithoutRoot += MaxSumRecursion(root.Right);
		}

		return Math.Max(sumWithRoot, sumWithoutRoot);
	}

}

public class Program
{
	public static void Main()
	{
		Node root = new Node(10);
		Node node1 = new Node(20);
		Node node2 = new Node(30);
		Node node3 = new Node(40);
		Node node4 = new Node(50);
		Node node5 = new Node(60);
		Node node6 = new Node(70);
		Node node7 = new Node(80);

		root.Left = node1;
		root.Right = node2;
		node1.Left = node3;
		node1.Right = node4;
		node2.Left = node5;
		node2.Right = node6;
		node5.Left = node7;

		int maxSumRecursion = TaskUtils.MaxSumRecursion(root);
		Console.WriteLine("Maximum sum with recursion: " + maxSumRecursion);

		int maxSumDynamicProgramming = TaskUtils.MaxSumDynamic(root);
		Console.WriteLine("Maximum sum using dynamic programming: " + maxSumDynamicProgramming);

		
	}
}
