﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.Drawing;

namespace PirmaUzduotis
{
	class Node
	{
		public int Value { get; set; }
		public List<Node> Children { get; set; }

		public Node(int value, List<Node> children)
		{
			Value = value;
			Children = children;
		}
		public static Node CreateRandomTree(int size)
		{
			if (size < 1)
			{
                return null;
			}

			Random random = new Random();
			int value = random.Next(100);
			List<Node> children = new List<Node>();
			for (int i = 0; i < size; i++)
			{
				int childSize = random.Next(0, size - i);
				Node node = CreateRandomTree(childSize);
				if (node != null) 
				{ 
					children.Add(node);
					i += childSize;
				}
			}

			return new Node(value, children);
		}
	}

	class TaskUtils
	{
		public static int FindMaxSumRecursion(Node node)
		{
			int included = node.Value;
			foreach (var child in node.Children)
			{
				foreach (var grandchild in child.Children)
				{
					included += FindMaxSumRecursion(grandchild);
				}
			}
			int excluded = 0;
			foreach (var child in node.Children)
			{
				excluded += FindMaxSumRecursion(child);
			}
			return Math.Max(included, excluded);
		}

		public static int FindMaxSumDynamic(Node node)
		{
			if (node == null) return 0;

			Dictionary<Node, int> memo = new Dictionary<Node, int>();
			Stack<Node> stack = new Stack<Node>();
			stack.Push(node);

			while (stack.Count > 0)
			{
				Node current = stack.Peek();

				if (current.Children.Count == 0)
				{
					memo[current] = current.Value;
					stack.Pop();
				}
				else
				{
					bool allChildrenVisited = true;
					int sum = current.Value;
					foreach (Node child in current.Children)
					{
						if (!memo.ContainsKey(child))
						{
							stack.Push(child);
							allChildrenVisited = false;
						}
						else
						{
							sum += memo[child];
						}
						foreach (Node grandchild in child.Children)
						{
							if (memo.ContainsKey(grandchild))
							{
								sum -= memo[grandchild];
							}
						}
					}
					if (allChildrenVisited)
					{
						int exclude = 0;
						if (current.Children.Count > 0)
						{
							exclude = memo[current.Children[0]];
						}
						memo[current] = Math.Max(sum, exclude);
						stack.Pop();
					}
				}
			}

			return memo[node];
		}

		public static void PrintTreeHorizontally(Node root)
		{
			if (root == null)
			{
				return;
			}

			Queue<Node> queue = new Queue<Node>();
			queue.Enqueue(root);

			while (queue.Count > 0)
			{
				int levelSize = queue.Count;

				for (int i = 0; i < levelSize; i++)
				{
					Node node = queue.Dequeue();
					Console.Write(node.Value.ToString().PadLeft(3));

					if (i < levelSize - 1)
					{
						Console.Write("─┬");
					}

					foreach (Node child in node.Children)
					{
						queue.Enqueue(child);
					}
				}

				Console.WriteLine();
			}
		}
	}

	class Program
	{
		static void Main(string[] args)
		{
			var stopWatch = new Stopwatch();
			stopWatch.Start();
			int n = 250000;
			Node tree = Node.CreateRandomTree(n);
			//TaskUtils.PrintTree(tree);
			//Create a sample tree
			Node root = new Node(10, new List<Node>());
			Node node1 = new Node(20, new List<Node>());
			Node node2 = new Node(30, new List<Node>());
			Node node3 = new Node(40, new List<Node>());
			Node node4 = new Node(50, new List<Node>());
			Node node5 = new Node(60, new List<Node>());
			Node node6 = new Node(70, new List<Node>());
			Node node7 = new Node(80, new List<Node>());

			root.Children.Add(node1);
			root.Children.Add(node2);
			node1.Children.Add(node3);
			node1.Children.Add(node4);
			node2.Children.Add(node5);
			node2.Children.Add(node6);
			node5.Children.Add(node7);
			//TaskUtils.PrintTreeHorizontally(root);


			// Find the maximum sum using recursion
			int maxSumRecursion = TaskUtils.FindMaxSumRecursion(root);
			Console.WriteLine("Maximum sum using recursion: " + maxSumRecursion);
			stopWatch.Stop();
			Console.WriteLine("Time in milliseconds for FIRST({1}): {0} ms", stopWatch.ElapsedMilliseconds.ToString(), n);

			stopWatch.Start();
			Node node10 = new Node(100, new List<Node>());
			Node node20 = new Node(50, new List<Node>());
			Node node30 = new Node(75, new List<Node>());
			Node node40 = new Node(25, new List<Node>());
			Node node50 = new Node(175, new List<Node>());
			Node node60 = new Node(125, new List<Node>());
			Node node70 = new Node(50, new List<Node>());
			Node node80 = new Node(100, new List<Node>());
			Node node90 = new Node(50, new List<Node>());
			Node node100 = new Node(200, new List<Node>());
			Node node110 = new Node(150, new List<Node>());

			node10.Children.Add(node20);
			node10.Children.Add(node30);
			node20.Children.Add(node40);
			node20.Children.Add(node50);
			node30.Children.Add(node60);
			node30.Children.Add(node70);
			node40.Children.Add(node80);
			node50.Children.Add(node90);
			node50.Children.Add(node100);
			node60.Children.Add(node110);

			int maxSumDynamic = TaskUtils.FindMaxSumDynamic(node10);
			Console.WriteLine("Maximum sum using dynamic: " + maxSumDynamic);
			stopWatch.Stop();
			Console.WriteLine("Time in milliseconds for SECOND({1}): {0} ms", stopWatch.ElapsedMilliseconds.ToString(), n);

			//The answer of 250 is obtained by selecting the following nodes from the tree:
			//	Node with value 40
			//	Node with value 50
			//	Node with value 70
			//	Node with value 80

			//These nodes have a total value of 40 + 50 + 70 + 80 = 250, and satisfy the constraint that no node is included whose parent is already included. 
			//Note that we cannot select node 60, since its parent node 30 is already included.
			//To find the maximum sum of values that can be assigned to nodes in the tree, the MaxSum method uses a dynamic programming approach.
			//It calculates the maximum sum of values that can be obtained by including and excluding each node in the tree, and uses memoization to avoid redundant computations.

		}

	}
}