﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Metrics;

namespace PirmaRekursija
{
	class Node
	{
		public int val;
		public Node left, right;

		public Node(int val)
		{
			this.val = val;
			this.left = null;
			this.right = null;
		}
	}

	class Program
	{
		static void Main(string[] args)
		{
			Node root = new Node(1);
			root.left = new Node(2);
			root.left.left = new Node(4);
			root.left.right = new Node(5);
			root.right = new Node(3);
			root.right.left = new Node(6);
			root.right.right = new Node(7);

			Console.WriteLine(MaxSum(root));
		}

		static int MaxSum(Node node)
		{
			if (node == null)
			{
				return 0;
			}

			int incl = node.val;
			if (node.left != null)
			{
				incl += MaxSum(node.left.left) + MaxSum(node.left.right);
			}
			if (node.right != null)
			{
				incl += MaxSum(node.right.left) + MaxSum(node.right.right);
			}

			int excl = MaxSum(node.left) + MaxSum(node.right);

			return Math.Max(incl, excl);
		}
	}

	//class TreeNode
	//{
	//	public int val;
	//	public TreeNode left, right;
	//	public TreeNode(int val)
	//	{
	//		this.val = val;
	//	}
	//}

	//class Solution
	//{
	//	public static int MaxSum(TreeNode node)
	//	{
	//		if (node == null)
	//		{
	//			return 0;
	//		}

	//		// Exclude the current node and include its children
	//		int sum1 = MaxSum(node.left) + MaxSum(node.right);

	//		// Include the current node's value and its grandchildren
	//		int sum2 = node.val;
	//		if (node.left != null)
	//		{
	//			sum2 += MaxSum(node.left.left) + MaxSum(node.left.right);
	//		}
	//		if (node.right != null)
	//		{
	//			sum2 += MaxSum(node.right.left) + MaxSum(node.right.right);
	//		}

	//		// Return the maximum of the two sums
	//		return Math.Max(sum1, sum2);
	//	}

	//	static void Main(string[] args)
	//	{
	//		TreeNode root = new TreeNode(1);
	//		root.left = new TreeNode(2);
	//		root.right = new TreeNode(3);
	//		root.left.left = new TreeNode(4);
	//		root.left.right = new TreeNode(5);
	//		root.right.left = new TreeNode(6);
	//		root.right.right = new TreeNode(7);

	//		int maxSum = MaxSum(root);
	//		Console.WriteLine("Maximum sum of non-adjacent nodes: " + maxSum);
	//	}
	//}

	//class Program
	//{
	//	static void Main(string[] args)
	//	{
	//		// Sukurkite Node objektą su savo norimu medžio mazgų struktūra ir reikšmėmis
	//		Node rootNode = new Node(1)
	//		{
	//			Children = new List<Node>
	//			{	
	//				new Node(2)
	//				{
	//					Children = new List<Node>
	//					{
	//						new Node(4),
	//						new Node(5)
	//					}
	//				},
	//				new Node(3)
	//				{
	//					Children = new List<Node>
	//					{
	//						new Node(6),
	//						new Node(7)
	//					}
	//				}
	//			}
	//		};

	//		// Iškvieskite FindMaxSum metodą ir perduokite Node objektą kaip parametrą
	//		int maxSum = FindMaxSum(rootNode);

	//		Console.WriteLine(maxSum); // Atspausdins "18", nes didžiausia suma yra 1 + 4 + 5 + 6 + 7 = 18


	//	}
	//	public class Node
	//	{
	//		public int Value { get; set; }
	//		public List<Node> Children { get; set; }

	//		public Node(int value)
	//		{
	//			Value = value;
	//			Children = new List<Node>();
	//		}
	//	}

	//	public static int FindMaxSum(Node node)
	//	{
	//		if (node == null)
	//		{
	//			return 0;
	//		}

	//		int sumWithNode = node.Value;
	//		int sumWithoutNode = 0;

	//		foreach (var child in node.Children)
	//		{
	//			// Recursively calculate the sum with and without the child node
	//			sumWithNode += FindMaxSum(child, true);
	//			sumWithoutNode += FindMaxSum(child, false);
	//		}

	//		// Return the maximum sum
	//		return Math.Max(sumWithNode, sumWithoutNode);
	//	}

	//	public static int FindMaxSum(Node node, bool includeNode)
	//	{
	//		if (node == null)
	//		{
	//			return 0;
	//		}

	//		int sum = 0;

	//		if (includeNode)
	//		{
	//			sum += node.Value;
	//		}

	//		foreach (var child in node.Children)
	//		{
	//			// Recursively calculate the sum with and without the child node
	//			if (includeNode)
	//			{
	//				sum += FindMaxSum(child, false);
	//			}
	//			else
	//			{
	//				sum += FindMaxSum(child, true);
	//			}
	//		}

	//		return sum;
	//	}

	//		class Node
	//		{
	//			public int Value { get; set; }
	//			public List<Node> Children { get; set; }

	//			public Node(int value)
	//			{
	//				Value = value;
	//				Children = new List<Node>();
	//			}

	//			public int MaxSum()
	//			{
	//				int maxIncluded = Value;
	//				int maxExcluded = 0;

	//				foreach (Node child in Children)
	//				{
	//					maxIncluded += child.MaxSum().maxExcluded;
	//					maxExcluded += Math.Max(child.MaxSum().maxIncluded, child.MaxSum().maxExcluded);
	//				}

	//				return Math.Max(maxIncluded, maxExcluded);
	//			}
	//		}

	//		// Example usage:
	//		Node root = new Node(5);
	//		Node child1 = new Node(3);
	//		Node child2 = new Node(7);
	//		Node grandchild1 = new Node(1);
	//		Node grandchild2 = new Node(4);
	//		Node grandchild3 = new Node(10);

	//		root.Children.Add(child1);
	//		root.Children.Add(child2);
	//		child1.Children.Add(grandchild1);
	//		child1.Children.Add(grandchild2);
	//		child2.Children.Add(grandchild3);

	//		int maxSum = root.MaxSum(); // maxSum = 19



}

