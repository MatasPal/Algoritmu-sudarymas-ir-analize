﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Metrics;

namespace PirmaRekursija
{
	class Node
	{
		public int Value;
		public Node[] Children;
		public bool Included;
		public static int TreeMaximumNonAdjacentSum(Node node)
		{
			if (node == null) return 0;
			if (node.Children == null || node.Children.Length == 0) return node.Value;
			if (node.Included) return TreeMaximumNonAdjacentSum(node.Children[0]);
			node.Included = true;
			int sum1 = TreeMaximumNonAdjacentSum(node.Children[0]);
			int sum2 = TreeMaximumNonAdjacentSum(node.Children[0]);
			node.Included = false;
			return node.Value + Math.Max(sum1, sum2);
		}

	}

	class Tree
	{
		public Node Root;
	}


	class Program
	{
		static void Main(string[] args)
		{
			Tree tree = new Tree();
			tree.Root = new Node { Value = 4 };
			tree.Root.Children = new Node[]
			{
				new Node { Value = 2 },
				new Node { Value = 5 },
				new Node { Value = 1 },
				new Node { Value = 3 }
			};
			tree.Root.Children[0].Children = new Node[]
			{
				new Node { Value = 1 },
				new Node { Value = 6 }
			};

			//The sum is obtained by including nodes with values 4, 5, and 1, while skipping nodes with values 2 and 3, as they are adjacent to node with value 4.
			int maxSum = Node.TreeMaximumNonAdjacentSum(tree.Root);
			Console.WriteLine("Maximum Non-Adjacent Sum: " + maxSum);
		}

	}
}