﻿using System;
using System.Collections.Generic;

class Program
{
	//static Dictionary<Node, int> memo = new Dictionary<Node, int>();

	static int MaxSum(Node node)
	{
		if (node == null) return 0;

		Dictionary<Node, int> memo = new Dictionary<Node, int>();
		Stack<Node> stack = new Stack<Node>();
		stack.Push(node);

		while (stack.Count > 0)
		{
			Node current = stack.Peek();

			if (current.Children.Count == 0)
			{
				memo[current] = current.Value;
				stack.Pop();
			}
			else
			{
				bool allChildrenVisited = true;
				int sum = current.Value;
				foreach (Node child in current.Children)
				{
					if (!memo.ContainsKey(child))
					{
						stack.Push(child);
						allChildrenVisited = false;
					}
					else
					{
						sum += memo[child];
					}
					foreach (Node grandchild in child.Children)
					{
						if (memo.ContainsKey(grandchild))
						{
							sum -= memo[grandchild];
						}
					}
				}
				if (allChildrenVisited)
				{
					int exclude = 0;
					if (current.Children.Count > 0)
					{
						exclude = memo[current.Children[0]];
					}
					memo[current] = Math.Max(sum, exclude);
					stack.Pop();
				}
			}
		}

		return memo[node];
	}


	static void Main(string[] args)
	{
		// Create the tree structure
		Node node1 = new Node(100, new List<Node>());
		Node node2 = new Node(50, new List<Node>());
		Node node3 = new Node(75, new List<Node>());
		Node node4 = new Node(25, new List<Node>());
		Node node5 = new Node(175, new List<Node>());
		Node node6 = new Node(125, new List<Node>());
		Node node7 = new Node(50, new List<Node>());
		Node node8 = new Node(100, new List<Node>());
		Node node9 = new Node(50, new List<Node>());
		Node node10 = new Node(200, new List<Node>());
		Node node11 = new Node(150, new List<Node>());

		node1.Children.Add(node2);
		node1.Children.Add(node3);
		node2.Children.Add(node4);
		node2.Children.Add(node5);
		node3.Children.Add(node6);
		node3.Children.Add(node7);
		node4.Children.Add(node8);
		node5.Children.Add(node9);
		node5.Children.Add(node10);
		node6.Children.Add(node11);

		// Calculate the maximum sum
		int maxSum = MaxSum(node1);

		Console.WriteLine("Maximum sum: " + maxSum);
	}
}

class Node
{
	public int Value { get; set; }
	public List<Node> Children { get; set; }

	public Node(int value, List<Node> children)
	{
		Value = value;
		Children = children;
	}
}
