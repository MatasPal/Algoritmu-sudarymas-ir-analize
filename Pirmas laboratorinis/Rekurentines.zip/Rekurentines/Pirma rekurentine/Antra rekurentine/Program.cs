﻿using System.Diagnostics;

internal class Recurental2
{
    //counter
    private static int counter;
    static void Main(string[] args)
    {
        Tests(new int[1]);
        Tests(new int[8]);
        Tests(new int[16]);
        Tests(new int[24]);
        Tests(new int[48]);
        Console.Read();
    }
    public static void Tests(int[] list)
    {
        var functionTime = new Stopwatch();
        counter = 0;
        functionTime.Start();
        Rec2(list, 0, list.Length);
        functionTime.Stop();
        Console.WriteLine($"Function working time: {functionTime.Elapsed}");
        Console.WriteLine($"Elements amount: {list.Length}");
        Console.WriteLine($"Counter: {counter}");
        Console.WriteLine();
    }
    public static void Rec2(int[] A, int start, int end)
    {
        if (end <= 0)
            return;

        Rec2(A, start, end / 4);
        Rec2( A, start, end / 9);

        for(int i = 0; i < end; i++)
        {
            for(int j = 0; j < end; j++)
            {
                for(int k = 0; k < end; k++)
                {
                    counter++;
                }
            }
        }
    }
}
