﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Xml.Linq;

internal class Recurental1
{
    //counter
    private static int counter;
    static void Main(string[] args)
    {
        Tests(new int[1]);
        Tests(new int[8]);
        Tests(new int[16]);
        Tests(new int[24]);
        Tests(new int[48]);
        Console.Read();
    }
    public static void Tests(int[] list)
    {
        var functionTime = new Stopwatch();
        counter = 0;
        functionTime.Start();
        Rec1(list, 0, list.Length);
        functionTime.Stop();
        Console.WriteLine($"Function working time: {functionTime.Elapsed}");
        Console.WriteLine($"Elements amount: {list.Length}");
        Console.WriteLine($"Counter: {counter}");
        Console.WriteLine();
    }
    public static void Rec1(int[] A, int start, int end)
    {
        if (end <= 0)
        {
            return;
        }

        Rec1( A, start, end / 6);
        Rec1( A, start, end / 6);

        for (int i = start; i < end; i++)
        {
            for (int j = start; j < end; j++)
            {
                for (int y = start; y < end; y++)
                {
                    for (int k = start; k < end; k++)
                    {
                        counter++;
                    }
                }
            }
        }
    }
}