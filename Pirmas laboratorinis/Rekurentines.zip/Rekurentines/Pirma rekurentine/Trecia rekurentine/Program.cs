﻿using System.Diagnostics;

internal class Recurental3
{
    //counter
    private static int counter;
    static void Main(string[] args)
    {
        Tests(new int[1]);
        Tests(new int[2]);
        Tests(new int[4]);
        Tests(new int[8]);
        Tests(new int[16]);
        Console.Read();
    }
    public static void Tests(int[] list)
    {
        var functionTime = new Stopwatch();
        counter = 0;
        functionTime.Start();
        Rec3(list, 0, list.Length);
        functionTime.Stop();
        Console.WriteLine($"Function working time: {functionTime.Elapsed}");
        Console.WriteLine($"Elements amount: {list.Length}");
        Console.WriteLine($"Counter: {counter}");
        Console.WriteLine();
    }
    public static void Rec3(int[] A, int start, int end)
    {
        if (end <= 0)
            return;

        Rec3(A, start, end - 3);
        Rec3(A, start, end - 1);

        for (int i = 0; i < end; i++)
        {                        
            counter++;               
        }
    }
}

